package lv.venta.demo.controllers;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.context.request.WebRequest;

import lv.venta.demo.models.User;
@Controller
public class simpleTestController {

	@GetMapping("/simpl")
	public String simpleFunc()
	{
		System.out.println("Tiek izsaukta func");
		return "home";
	}
	
	
	
}
