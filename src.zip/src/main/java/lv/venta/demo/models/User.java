package lv.venta.demo.models;



import java.util.Collection;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import javax.validation.constraints.NotNull;


import lombok.AccessLevel;
import lombok.Getter;

import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name= "user", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
@Setter
@Getter
@ToString
public class User {

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Setter(value=AccessLevel.NONE)
	@Column(name="id")
	private Long id;
	
	
	@Column(name="name")
	private String name;
	

	@Column(name="nurname")
	private String surname;
	

	@Column(name="password")
	private String password;
	

	  @Column(name="email")
	private String email;
	


	
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(
			name = "users_roles",
			joinColumns = @JoinColumn(
					name = "user_id", referencedColumnName = "id"),
			inverseJoinColumns = @JoinColumn(
					name = "role_id", referencedColumnName = "id"))
	private Collection<Role>roles;

public User() {
		
	}
	

	public User(String name, String surname,  String password,String email, Collection<Role> roles) {
		super();

		this.name = name;
		this.surname = surname;
		this.password = password;
		this.email = email;
		this.roles = roles;
	}


	


	











	public Long getIdUser() {
		return id;
	}









	public String getName() {
		return name;
	}










	public void setName(String name) {
		this.name = name;
	}










	public String getSurname() {
		return surname;
	}










	public void setSurname(String surname) {
		this.surname = surname;
	}










	public String getPassword() {
		return password;
	}










	public void setPassword(String password) {
		this.password = password;
	}










	public String getEmail() {
		return email;
	}










	public void setEmail(String email) {
		this.email = email;
	}










	public Collection<Role> getRoles() {
		return roles;
	}










	public void setRoles(Collection<Role> roles) {
		this.roles = roles;
	}
	

	





	
	
}

